import provinces from './provinces.mjs';

document.addEventListener('DOMContentLoaded', function() {
  // 添加标签页更新事件监听器
  chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
      // 这里可以添加你的条件，比如匹配特定的网址
      if (tab.url.includes("douban.com")) {
          // 当标签页的 URL 包含 "example.com" 时，将徽章背景颜色设置为绿色
          chrome.browserAction.setBadgeBackgroundColor({ color: [0, 255, 0, 255] });
      } else {
          // 如果不匹配条件，则将徽章背景颜色设置为其他颜色或者移除徽章
          // 这里的示例是将背景颜色设置为红色
          chrome.browserAction.setBadgeBackgroundColor({ color: [255, 0, 0, 255] });
      }
  });
});




document.addEventListener("DOMContentLoaded", function () {
    const provinceList = document.getElementById("provinceList");
    
    document.getElementById('openOptions').addEventListener('click', function() {
        chrome.tabs.create({url: 'options.html'});
      });


    chrome.runtime.sendMessage(
        { action: "getProvinceStatus" },
        function (response) {
            //console.log("Received province status:", response.provinceStatus);
            const selectedProvinceCode = Object.keys(response.provinceStatus)[0];
            console.log("Selected province:", selectedProvinceCode);
            const selectedProvince = provinces.find(
                (province) => province.code === selectedProvinceCode
            );
            const selectedProvinceName = selectedProvince
                ? selectedProvince.name
                : "未知省份"; // 如果未找到匹配的省份信息，则使用默认值  ${selectedProvinceCode}   <img src="https://digi.library.hb.cn:8443/img/logo-title.c073cc07.png" />
            console.log("Selected province:", selectedProvinceName);

            let key = { code: response.provinceStatus };
            const item = document.createElement("div");
           // item.classList.add("flex", "items-center", "text-xl");
            item.innerHTML = `
              <label class="items-center">
                  <p>${selectedProvinceName}图书馆</p>
              </label>
            `;
            provinceList.appendChild(item);
        }
    );
});
